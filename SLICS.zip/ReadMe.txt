Usage:	
	SLICS.exe [ OPTIONS ] IMAGENAME

Options:
	--geodesic		geodesic sampling or Hammersley sampling (default) for seeds
	--global		global search or local search (default)
	-n, --number=ARG	subdivision level or number of sampling points
	-t, --type=ARG		distance type
	-w, --weight=ARG	weight of color distance
	-o, --outname=ARG	outname

Details about the parameters:
	1. The number parameter is highly related to the --geodesic option. If you use the geodesic sampling, this parameter is the subdivision level when 
	   construcing the geodesic grid. You can set it as 3 or 4. If you use the Hammersley sampling, this parameter is the number of sampling points. In this 
	   case, you can set it as 1000 for example.
	2. The --global option is used for global search. The users are not suggested to set this option, as it will take a long time to generate the superpixels.
	3. The type parameter specifies the type of distance used in the assignment step and the update step. The parameter is 1 for Euclidean distance, 2 for Cos-SphSLIC 
	   (default) and 3 for Avg-SphSLIC. 
	4. The weight parameter gives the weight of color distance, whose default value is 1.0. Intuitionally, a larger weight will give superpixels adhering better 
	   to image boundaries. But the superpixels will also be more irregular.
	5. The outname parameter sets the name of output image file and text file, where the image gives the visual segmentation result and the text contains labels 
	   for the pixels in row order.

Basic example:
	SLICS.exe -o sp 14.jpg			//Segment 14.jpg into spherical superpixels using default setting

Advanced examples:

	You can compare the resuls of different initialization methods. You will find that geodesic sampling will give more regular spherical superpixels.
	SLICS.exe --geodesic -n 3 -o geo black.bmp	// Segment black.bmp into superpixels using seed points initialized by geodesic sampling.
	SLICS.exe -n 642 -o ham black.bmp		// Segment black.bmp into the same number of superpixels using seed points initialized by Hammersley sampling.

	You can also compare the spherical superpixel segmentation results when giving different color weights.
	SLICS.exe -n 1000 -o sp1 14.jpg		//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 1
	SLICS.exe -n 1000 -w 2 -o sp2 14.jpg	//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 2
	SLICS.exe -n 1000 -w 9 -o sp9 14.jpg	//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 9

Citation:
	If you use this executable in your work, please cite our paper as follow.
	@ARTICLE{SLICS, 
		author={Q. {Zhao} and F. {Dai} and Y. {Ma} and L. {Wan} and J. {Zhang} and Y. {Zhang}}, 
		journal={IEEE Transactions on Multimedia}, 
		title={Spherical Superpixel Segmentation}, 
		year={2018}, 
		volume={20}, 
		number={6}, 
		pages={1406-1417},
	}