Usage:	
	SLICS.exe [ OPTIONS ] IMAGENAME


Options:
	--geodesic             geodesic sampling or Hammersley sampling (default) for seeds
	--global               global search or local search (default)
	-n, --number=ARG       subdivision level or number of sampling points
	-t, --type=ARG         distance type
	-w, --weight=ARG       weight of color distance
	-o, --outname=ARG      the name of output image file and text file, where the image gives the visual segmentation result 
				and the text contains labels for the pixels in row order


Examples:
	SLICS.exe -o sp 14.jpg			//Segment 14.jpg into spherical superpixels using default setting
	SLICS.exe -n 1000 -o sp1 14.jpg		//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 1
	SLICS.exe -n 1000 -w 2 -o sp2 14.jpg	//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 2
	SLICS.exe -n 1000 -w 9 -o sp9 14.jpg	//Segment 14.jpg into about 1000 spherical superpixels with the weight of color distance as 9


Citation:
	If you use this executable in your work, please cite our paper as follow.
	@ARTICLE{SLICS, 
		author={Q. {Zhao} and F. {Dai} and Y. {Ma} and L. {Wan} and J. {Zhang} and Y. {Zhang}}, 
		journal={IEEE Transactions on Multimedia}, 
		title={Spherical Superpixel Segmentation}, 
		year={2018}, 
		volume={20}, 
		number={6}, 
		pages={1406-1417},
	}